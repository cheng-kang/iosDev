//
//  SecondViewController.swift
//  Track Your Skin
//
//  Created by Kang Cheng on 5/11/20.
//  Copyright © 2020 root. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

